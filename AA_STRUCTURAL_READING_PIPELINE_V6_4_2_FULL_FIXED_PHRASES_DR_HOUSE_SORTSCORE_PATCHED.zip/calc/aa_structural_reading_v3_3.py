#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from typing import Any, Dict, List, Tuple, Optional

ORB_STRUCT=2.0
ORB_ORIENT=2.0
ORB_ORIENT_LUMINARIES=6.5
SCORE_MIN=4
SCORE_OVERFLOW=8

ASPECT_HARD={"square","opposition"}
ASPECT_SOFT={"trine","sextile"}
ASPECT_CONJ={"conjunction"}

POINTS={"North Node","Lilith","Chiron"}
LUMINARIES={"Sun","Moon"}
ANGULAR_HOUSES={1,4,7,10}

ARCANA_NAMES={
 "I":"Il Bagatto","II":"La Papessa","III":"L'Imperatrice","IV":"L'Imperatore",
 "VI":"Gli Amanti","VIII":"La Giustizia","IX":"L'Eremita","X":"La Ruota della Fortuna",
 "XI":"La Forza","XII":"L'Appeso","XIII":"La Morte","XIV":"La Temperanza",
 "XV":"Il Diavolo","XVI":"La Torre","XVIII":"La Luna","XIX":"Il Sole",
 "XX":"Il Giudizio","XXII":"Il Matto"
}

DUP_FALLBACK={
 "XV":["XIII","XVI","XII","IV","X","XIV","XI","III","VI","XX","XIX","II","XVIII","I","IX","VIII","XXII"],
 "IV":["VIII","XIV","X","XV","XII","XX","XIX","II","XVIII","I","XI","III","VI","XVI","XIII","IX","XXII"],
 "XII":["XVIII","IX","X","XIV","I","XXII","XV","XIII","IV","VIII","XX","II","XIX","XI","III","VI","XVI"],
 "X":["XIV","XV","XIII","XII","IV","VIII","XX","II","XVIII","XIX","I","IX","XI","III","VI","XVI","XXII"],
 "XVIII":["II","XII","IX","X","XIV","XXII","XV","XIII","IV","VIII","XX","XIX","I","XI","III","VI","XVI"],
 "XX":["XXII","XIX","XV","XIII","IV","XII","X","XIV","XI","III","VI","II","XVIII","I","IX","VIII","XVI"],
 "XVI":["XI","XV","XIII","X","XII","IV","VIII","XXII","XX","XIX","II","XVIII","I","IX","XIV","III","VI"],
 "XIII":["XVI","XV","XVIII","XII","X","IV","VIII","XX","XIX","II","I","IX","XIV","XI","III","VI","XXII"],
 "XIV":["X","VIII","IV","XX","XIX","II","XVIII","I","IX","XI","III","VI","XII","XVI","XV","XIII","XXII"],
 "XI":["XVI","IV","XIV","X","XV","XII","XX","XIX","II","XVIII","I","IX","VIII","III","VI","XIII","XXII"],
 "III":["VI","XI","XIV","X","XX","XIX","II","XVIII","I","IX","VIII","IV","XII","XVI","XV","XIII","XXII"],
 "VI":["III","I","XI","XIV","X","XX","XIX","II","XVIII","IX","VIII","IV","XII","XVI","XV","XIII","XXII"],
 "I":["VI","III","XI","XIV","X","XX","XIX","II","XVIII","IX","VIII","IV","XII","XVI","XV","XIII","XXII"],
 "IX":["XII","XVIII","I","II","X","XIV","XI","III","VI","IV","XV","XIII","XVI","XX","XIX","VIII","XXII"],
 "VIII":["IV","XIV","X","XX","XIX","II","XVIII","I","IX","XI","III","VI","XII","XVI","XV","XIII","XXII"],
 "XXII":["XX","XVI","X","XIV","XI","III","VI","I","IX","XII","XV","XIII","IV","VIII","XIX","II","XVIII"],
}

def _extract_json(text:str)->Dict[str,Any]:
    t=text.strip()
    if t.startswith("{") and t.endswith("}"):
        return json.loads(t)
    m=re.search(r"\{.*\}\s*$",t,flags=re.S) or re.search(r"\{.*\}",t,flags=re.S)
    if not m: raise ValueError("No JSON found")
    return json.loads(m.group(0))

def load(path:str)->Dict[str,Any]:
    with open(path,"r",encoding="utf-8") as f:
        return _extract_json(f.read())

def norm(name:str)->str:
    n=(name or "").strip()
    if n in {"North Node (Mean)","North Node"}: return "North Node"
    if n in {"Lilith (Black Moon Mean)","Lilith"}: return "Lilith"
    return n

def parse_positions(d:Dict[str,Any])->Dict[str,Dict[str,Any]]:
    bodies={}
    for p in d.get("positions",[]) or []:
        b=norm(p.get("body"))
        if b: bodies[b]=p
    return bodies

def house_of(o:Dict[str,Any])->Optional[int]:
    try: return int(o.get("house"))
    except: return None

def sign_of(o:Dict[str,Any])->Optional[str]:
    s=o.get("sign")
    return s.strip() if isinstance(s,str) else None

def parse_aspects(d:Dict[str,Any])->List[Tuple[str,str,str,float]]:
    out=[]
    for a in d.get("aspects",[]) or []:
        try:
            p1=norm(a.get("a"))
            p2=norm(a.get("b"))
            t=(a.get("aspect") or "").strip().lower()
            orb=float(a.get("orb_dec",999))
            if p1 and p2 and t:
                out.append((p1,p2,t,orb))
        except:
            pass
    return out

def build_house_idx(bodies)->Dict[int,List[str]]:
    idx={h:[] for h in range(1,13)}
    for nm,o in bodies.items():
        h=house_of(o)
        if h in idx: idx[h].append(nm)
    return idx

def has_between(aspects,x,y,types:set,orb_max:float)->bool:
    for a,b,t,orb in aspects:
        if orb<=orb_max and {a,b}=={x,y} and t in types:
            return True
    return False

def internal_aspects(aspects, members:set)->List[Tuple[str,str,str,float]]:
    res=[]
    for a,b,t,orb in aspects:
        if orb>ORB_STRUCT: continue
        if a in members and b in members:
            res.append((a,b,t,orb))
    return res

def intensity_score(house:int, members:List[str], aspects)->int:
    mem=set(members)
    planets=[m for m in members if m not in POINTS]
    S1=len(members)>=2
    S2=any(orb<=ORB_STRUCT and (a in mem or b in mem) for a,b,t,orb in aspects)
    S3=len(planets)>=3
    S4=any(m in LUMINARIES for m in members) and house in ANGULAR_HOUSES
    score=0
    if S3: score+=4
    if S1: score+=3
    if S2: score+=2
    if S4: score+=3
    for o in ("Uranus","Neptune","Pluto"):
        if o in mem: score+=2
    if "Saturn" in mem: score+=1
    for p in ("North Node","Lilith","Chiron"):
        if p in mem: score+=1
    for a,b,t,orb in internal_aspects(aspects,mem):
        if t in ASPECT_HARD: score+=2
        elif t in ASPECT_SOFT: score+=1
        elif t in ASPECT_CONJ: score+=2
    if house in ANGULAR_HOUSES: score+=1
    return score

def orientation(members:List[str], aspects)->Tuple[str,List[Tuple[str,str,str,float]],int,int]:
    mem=set(members)
    C=T=0
    used=[]
    for a,b,t,orb in aspects:
        involves = (a in mem) or (b in mem) or ((a in {"ASC","MC"} and b in mem) or (b in {"ASC","MC"} and a in mem))
        if not involves: 
            continue
        lum = ("Sun" in {a,b}) or ("Moon" in {a,b})
        orb_max = ORB_ORIENT_LUMINARIES if lum else ORB_ORIENT
        if orb>orb_max: 
            continue
        if t in ASPECT_SOFT: C+=1
        elif t in ASPECT_HARD: T+=1
        used.append((a,b,t,orb))
    return ("r" if T>C else "d", used, T, C)

def dominant_body(members:List[str])->str:
    mem=set(members)
    for b in ("Pluto","Neptune","Uranus","Saturn","Sun","Moon","Jupiter","Mars","Venus","Mercury","North Node","Lilith","Chiron"):
        if b in mem:
            return b
    return members[0] if members else "UNKNOWN"

def arc_map(house:int, members:List[str], aspects, bodies, score:int, orient:str, hard_count:int)->str:
    mem=set(members)
    planets=[m for m in mem if m not in POINTS]
    planet_count=len(planets)
    dom=dominant_body(members)

    # R1
    if "Venus" in mem and "Pluto" in mem and has_between(aspects,"Venus","Pluto",ASPECT_HARD|ASPECT_CONJ,ORB_STRUCT):
        return "XV"
    if "Pluto" in mem and (planet_count>=4 or has_between(aspects,"Saturn","Pluto",ASPECT_CONJ,ORB_STRUCT)):
        return "XV"
    # R2
    if house==8 and "Pluto" in mem and (("Lilith" in mem) or ("Chiron" in mem)):
        return "XIII"
    if house==8 and ("Lilith" in mem) and ("Chiron" in mem) and has_between(aspects,"Lilith","Chiron",ASPECT_CONJ,ORB_STRUCT):
        return "XIII"
    if house==8 and (("Lilith" in mem) or ("Chiron" in mem)):
        return "XIII"
    # R3 Neptune hard
    if "Neptune" in mem:
        personals={"Sun","Moon","Mercury","Venus","Mars"}
        for a,b,t,orb in aspects:
            if orb>ORB_STRUCT or t not in ASPECT_HARD: 
                continue
            if "Neptune" not in {a,b}: 
                continue
            other = b if a=="Neptune" else a
            if other in personals or other in {"ASC","MC"}:
                return "XII"
    # R4 Saturn
    if "Saturn" in mem and (house in {2,10} or planet_count>=3):
        return "IV"
    # R5 Justice
    if house==7 and "Jupiter" in mem and "Saturn" in mem and has_between(aspects,"Jupiter","Saturn",ASPECT_CONJ,ORB_STRUCT):
        return "VIII"
    # R6 Wheel
    if ("Jupiter" in mem and "Uranus" in mem) or ("Uranus" in mem and house==9):
        return "X"
    # R7 Judgement
    if house==1 and "North Node" in mem:
        for a,b,t,orb in aspects:
            if orb>ORB_STRUCT or t not in ASPECT_SOFT: 
                continue
            if "North Node" not in {a,b}: 
                continue
            if "Sun" in {a,b} or "Venus" in {a,b}:
                return "XX"
    # R8 Papessa
    if house==4 and "Moon" in mem:
        sign=sign_of(bodies.get("Moon",{}))
        if sign in {"Gemini","Libra","Aquarius"}:
            return "II"
    # R9 Sole
    if house==12 and "Sun" in mem and planet_count>=3:
        return "XIX"
    # R10 Luna
    if house==8 and "Moon" in mem and "Lilith" in mem and has_between(aspects,"Moon","Lilith",ASPECT_HARD,ORB_STRUCT):
        return "XVIII"

    # R11..R18
    if dom=="North Node": return "XX"
    if "North Node" in mem and "Uranus" in mem: return "XXII"
    if dom=="Lilith": return "XV" if orient=="r" else "XVI"
    if dom=="Chiron": return "XII" if orient=="r" else "IX"
    if dom=="Mercury": return "I" if orient=="d" else "XII"
    if dom=="Venus": return "III" if orient=="d" else "VI"
    if dom=="Mars": return "XI" if orient=="d" else "XVI"
    if dom=="Jupiter": return "XIV" if orient=="d" else "X"

    # M0 overflow
    if score>=SCORE_OVERFLOW and (("North Node" in mem) or ("Uranus" in mem) or (hard_count>=2)):
        return "XXII"

    # final fallback
    if "Pluto" in mem: return "XV"
    if "Neptune" in mem: return "XII"
    if "Uranus" in mem: return "X"
    if "Saturn" in mem: return "IV"
    if "Sun" in mem: return "XIX"
    if "Moon" in mem: return "XVIII"
    if "North Node" in mem: return "XX"
    if "Lilith" in mem: return "XVI"
    if "Chiron" in mem: return "IX"
    return "X"

def compute(path:str):
    d=load(path)
    bodies=parse_positions(d)
    aspects=parse_aspects(d)
    idx=build_house_idx(bodies)

    cands=[]
    for h in range(1,13):
        members=idx.get(h,[])
        if not members: 
            continue
        planets=[m for m in members if m not in POINTS]
        mem=set(members)
        S1=len(members)>=2
        S2=any(orb<=ORB_STRUCT and (a in mem or b in mem) for a,b,t,orb in aspects)
        S3=len(planets)>=3
        S4=any(m in LUMINARIES for m in members) and h in ANGULAR_HOUSES
        if not (S1 or S2 or S3 or S4):
            continue
        sc=intensity_score(h,members,aspects)
        orient, orient_aspects, T, C = orientation(members,aspects)
        arc=arc_map(h,members,aspects,bodies,sc,orient,T)
        cands.append({"house":h,"members":members,"score":sc,"arc":arc,"orient":orient,"orient_aspects":orient_aspects})

    cands.sort(key=lambda r:(-r["score"], r["house"]))
    selected=[r for r in cands if r["score"]>=SCORE_MIN]
    if len(selected)<4:
        for r in cands:
            if r in selected: 
                continue
            selected.append(r)
            if len(selected)>=4:
                break

    # S5 luminari attivi
    for h in range(1,13):
        members=idx.get(h,[])
        if not members: 
            continue
        if not any(m in LUMINARIES for m in members):
            continue
        cnt=0
        for a,b,t,orb in aspects:
            if "Sun" in members and "Sun" in {a,b} and orb<=ORB_ORIENT_LUMINARIES:
                cnt+=1
            if "Moon" in members and "Moon" in {a,b} and orb<=ORB_ORIENT_LUMINARIES:
                cnt+=1
        if cnt>=2 and not any(x["house"]==h for x in selected):
            sc=intensity_score(h,members,aspects)
            orient, orient_aspects, T, C = orientation(members,aspects)
            arc=arc_map(h,members,aspects,bodies,sc,orient,T)
            selected.append({"house":h,"members":members,"score":sc,"arc":arc,"orient":orient,"orient_aspects":orient_aspects})

    # anti-dup
    used=set()
    for r in sorted(selected, key=lambda r:(-r["score"], r["house"])):
        arc=r["arc"]
        if arc in used:
            for fb in DUP_FALLBACK.get(arc,[]):
                if fb not in used:
                    arc=fb
                    break
        if arc in used:
            for candidate in ARCANA_NAMES.keys():
                if candidate not in used:
                    arc=candidate
                    break
        r["arc"]=arc
        used.add(arc)

    selected.sort(key=lambda r:r["house"])
    return selected

def format_markdown(rows)->str:
    lines=[]
    lines.append("| Casa | Arcano | d/r | Score | Corpi | Aspetti stretti |")
    lines.append("| ---- | ------ | --- | ----- | ----- | --------------- |")
    for r in rows:
        arc=r["arc"]
        arc_label=f"{arc} {ARCANA_NAMES.get(arc,arc)}"
        aspects=";".join([f"{a}-{t}-{b}({orb:.2f})" for a,b,t,orb in r["orient_aspects"]])
        lines.append(f"| {r['house']} | {arc_label} | {r['orient']} | {r['score']} | {','.join(r['members'])} | {aspects} |")
    return "\\n".join(lines)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--json", required=True)
    args=ap.parse_args()
    print(format_markdown(compute(args.json)))

if __name__=="__main__":
    main()
