# tools/diff_v56_vs_v61.py
# Deterministic diff between two pipeline roots (v5.6 vs v6.1) on the same JSON batch.
# Usage:
#   python tools/diff_v56_vs_v61.py --v56 ../AA_V5_6_ROOT --v61 . --jsondir ./_jsons
import argparse, os, sys
from typing import Dict, Any, List

def load_compute(root: str):
    sys.path.insert(0, root)
    from calc.aa_structural_reading_v5 import compute, ARCANA_NAMES  # type: ignore
    return compute, ARCANA_NAMES

def arc_name(arc: str, names: Dict[str,str]) -> str:
    return names.get(arc, arc)

def idx(rows: List[Dict[str,Any]]) -> Dict[int, Dict[str,Any]]:
    return {int(r["house"]): r for r in rows}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v56", required=True, help="Root folder of V5.6 pipeline")
    ap.add_argument("--v61", required=True, help="Root folder of V6.1 pipeline")
    ap.add_argument("--jsondir", required=True, help="Folder with JSON_CU3 .txt files")
    args = ap.parse_args()

    compute56, names56 = load_compute(args.v56)
    # reset path injection before loading v61
    sys.path = [p for p in sys.path if p not in (args.v56,)]
    compute61, names61 = load_compute(args.v61)

    files = sorted([f for f in os.listdir(args.jsondir) if f.lower().endswith(".txt")])
    for f in files:
        p = os.path.join(args.jsondir, f)
        a = idx(compute56(p))
        b = idx(compute61(p))
        houses = sorted(set(a) | set(b))
        changes = []
        for h in houses:
            if h not in a or h not in b:
                continue
            if a[h]["arc"] != b[h]["arc"] or a[h]["orient"] != b[h]["orient"]:
                changes.append(h)
        if not changes:
            continue
        print("="*72)
        print(f)
        for h in changes:
            ra, rb = a[h], b[h]
            print(f"- Casa {h}: V5.6 -> {arc_name(ra['arc'], names56)} {ra['orient']} | "
                  f"V6.1 -> {arc_name(rb['arc'], names61)} {rb['orient']}")
            if "audit_conflict" in rb:
                print(f"  audit_conflict: {rb['audit_conflict']}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
